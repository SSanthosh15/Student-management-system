// Student Management System - Frontend logic
// Talks to the Flask REST API defined in backend/app.py

const API_BASE = "http://127.0.0.1:5000/api/students";

const form = document.getElementById("student-form");
const idField = document.getElementById("student-id");
const nameField = document.getElementById("name");
const emailField = document.getElementById("email");
const courseField = document.getElementById("course");
const marksField = document.getElementById("marks");

const formTitle = document.getElementById("form-title");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-btn");
const tbody = document.getElementById("students-tbody");
const emptyState = document.getElementById("empty-state");
const alertBanner = document.getElementById("alert-banner");
const searchInput = document.getElementById("search-input");

let studentsCache = [];

// ---------------------------------------------------------------
// Alerts
// ---------------------------------------------------------------
function showAlert(message, type = "success") {
  alertBanner.textContent = message;
  alertBanner.className = `alert ${type}`;
  alertBanner.classList.remove("hidden");
  setTimeout(() => alertBanner.classList.add("hidden"), 4000);
}

// ---------------------------------------------------------------
// Client-side validation (mirrors server-side rules)
// ---------------------------------------------------------------
function clearFieldErrors() {
  ["name", "email", "course", "marks"].forEach((f) => {
    document.getElementById(`${f}-error`).textContent = "";
  });
}

function validateForm() {
  clearFieldErrors();
  let valid = true;

  if (!nameField.value.trim()) {
    document.getElementById("name-error").textContent = "Name is required.";
    valid = false;
  }

  const emailVal = emailField.value.trim();
  const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  if (!emailVal) {
    document.getElementById("email-error").textContent = "Email is required.";
    valid = false;
  } else if (!emailRegex.test(emailVal)) {
    document.getElementById("email-error").textContent = "Enter a valid email address.";
    valid = false;
  }

  if (!courseField.value.trim()) {
    document.getElementById("course-error").textContent = "Course is required.";
    valid = false;
  }

  const marksVal = marksField.value;
  if (marksVal === "") {
    document.getElementById("marks-error").textContent = "Marks are required.";
    valid = false;
  } else if (Number(marksVal) < 0 || Number(marksVal) > 100) {
    document.getElementById("marks-error").textContent = "Marks must be between 0 and 100.";
    valid = false;
  }

  return valid;
}

// ---------------------------------------------------------------
// API calls
// ---------------------------------------------------------------
async function fetchStudents(search = "") {
  try {
    const url = search ? `${API_BASE}?search=${encodeURIComponent(search)}` : API_BASE;
    const res = await fetch(url);
    if (!res.ok) throw new Error("Failed to fetch students.");
    studentsCache = await res.json();
    renderTable(studentsCache);
  } catch (err) {
    showAlert(`Could not load students. Is the backend running? (${err.message})`, "error");
  }
}

async function createStudent(payload) {
  const res = await fetch(API_BASE, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Failed to create student.");
  return data;
}

async function updateStudent(id, payload) {
  const res = await fetch(`${API_BASE}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Failed to update student.");
  return data;
}

async function deleteStudent(id) {
  const res = await fetch(`${API_BASE}/${id}`, { method: "DELETE" });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Failed to delete student.");
  return data;
}

// ---------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------
function renderTable(students) {
  tbody.innerHTML = "";

  if (students.length === 0) {
    emptyState.classList.remove("hidden");
    return;
  }
  emptyState.classList.add("hidden");

  students.forEach((s) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${s.id}</td>
      <td>${escapeHtml(s.name)}</td>
      <td>${escapeHtml(s.email)}</td>
      <td>${escapeHtml(s.course)}</td>
      <td>${s.marks}</td>
      <td>
        <div class="actions-cell">
          <button class="btn btn-edit" data-id="${s.id}">Edit</button>
          <button class="btn btn-delete" data-id="${s.id}">Delete</button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---------------------------------------------------------------
// Form handling
// ---------------------------------------------------------------
function resetForm() {
  form.reset();
  idField.value = "";
  formTitle.textContent = "Add Student";
  submitBtn.textContent = "Add Student";
  cancelBtn.classList.add("hidden");
  clearFieldErrors();
}

function loadStudentIntoForm(student) {
  idField.value = student.id;
  nameField.value = student.name;
  emailField.value = student.email;
  courseField.value = student.course;
  marksField.value = student.marks;
  formTitle.textContent = `Edit Student #${student.id}`;
  submitBtn.textContent = "Save Changes";
  cancelBtn.classList.remove("hidden");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (!validateForm()) return;

  const payload = {
    name: nameField.value.trim(),
    email: emailField.value.trim(),
    course: courseField.value.trim(),
    marks: Number(marksField.value),
  };

  const editingId = idField.value;

  try {
    if (editingId) {
      await updateStudent(editingId, payload);
      showAlert("Student updated successfully.", "success");
    } else {
      await createStudent(payload);
      showAlert("Student added successfully.", "success");
    }
    resetForm();
    fetchStudents(searchInput.value.trim());
  } catch (err) {
    showAlert(err.message, "error");
  }
});

cancelBtn.addEventListener("click", resetForm);

tbody.addEventListener("click", async (e) => {
  const target = e.target;
  const id = target.getAttribute("data-id");
  if (!id) return;

  if (target.classList.contains("btn-edit")) {
    const student = studentsCache.find((s) => String(s.id) === id);
    if (student) loadStudentIntoForm(student);
  }

  if (target.classList.contains("btn-delete")) {
    const student = studentsCache.find((s) => String(s.id) === id);
    const label = student ? student.name : `#${id}`;
    if (confirm(`Delete student "${label}"? This cannot be undone.`)) {
      try {
        await deleteStudent(id);
        showAlert("Student deleted successfully.", "success");
        fetchStudents(searchInput.value.trim());
      } catch (err) {
        showAlert(err.message, "error");
      }
    }
  }
});

let searchTimeout;
searchInput.addEventListener("input", () => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(() => fetchStudents(searchInput.value.trim()), 300);
});

// ---------------------------------------------------------------
// Init
// ---------------------------------------------------------------
fetchStudents();
