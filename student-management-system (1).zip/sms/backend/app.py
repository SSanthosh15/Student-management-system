"""
Student Management System - Backend REST API
Stack: Flask + SQLite
Implements full CRUD per SOP section 7.5 / 7.6 with server-side validation
and exception handling (SOP section 9 and 11).
"""

import os
import re
import sqlite3
from flask import Flask, request, jsonify, g

DB_PATH = os.path.join(os.path.dirname(__file__), "students.db")

app = Flask(__name__)


@app.after_request
def add_cors_headers(response):
    # Allow the frontend (different origin/port) to call this API - SOP 7.7
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, PUT, PATCH, DELETE, OPTIONS"
    return response


@app.route("/api/students", methods=["OPTIONS"])
@app.route("/api/students/<int:student_id>", methods=["OPTIONS"])
def cors_preflight(student_id=None):
    return "", 204

EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


# --------------------------------------------------------------------------
# Database helpers
# --------------------------------------------------------------------------
def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS students (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            course TEXT NOT NULL,
            marks REAL NOT NULL CHECK (marks >= 0 AND marks <= 100)
        )
        """
    )
    conn.commit()
    conn.close()


# --------------------------------------------------------------------------
# Validation (SOP section 9 - Validation Requirements)
# --------------------------------------------------------------------------
def validate_student_payload(data, partial=False):
    """
    Validates incoming student data.
    If partial=True, only validates fields that are present (used for PATCH-style updates).
    Returns a list of error messages (empty list = valid).
    """
    errors = []

    if not partial or "name" in data:
        name = data.get("name", "")
        if not isinstance(name, str) or not name.strip():
            errors.append("Field 'name' is required and cannot be empty.")
        elif len(name.strip()) > 100:
            errors.append("Field 'name' must be under 100 characters.")

    if not partial or "email" in data:
        email = data.get("email", "")
        if not isinstance(email, str) or not email.strip():
            errors.append("Field 'email' is required and cannot be empty.")
        elif not EMAIL_REGEX.match(email.strip()):
            errors.append("Field 'email' must be a valid email address.")

    if not partial or "course" in data:
        course = data.get("course", "")
        if not isinstance(course, str) or not course.strip():
            errors.append("Field 'course' is required and cannot be empty.")

    if not partial or "marks" in data:
        marks = data.get("marks", None)
        if marks is None:
            errors.append("Field 'marks' is required.")
        else:
            try:
                marks_val = float(marks)
                if marks_val < 0 or marks_val > 100:
                    errors.append("Field 'marks' must be between 0 and 100.")
            except (TypeError, ValueError):
                errors.append("Field 'marks' must be a number.")

    return errors


def row_to_dict(row):
    return {
        "id": row["id"],
        "name": row["name"],
        "email": row["email"],
        "course": row["course"],
        "marks": row["marks"],
    }


# --------------------------------------------------------------------------
# Routes - CRUD REST API (SOP section 7.6)
# --------------------------------------------------------------------------
@app.route("/api/health", methods=["GET"])
def health_check():
    return jsonify({"status": "ok"}), 200


# CREATE
@app.route("/api/students", methods=["POST"])
def create_student():
    data = request.get_json(silent=True)
    if data is None:
        return jsonify({"error": "Request body must be valid JSON."}), 400

    errors = validate_student_payload(data)
    if errors:
        return jsonify({"error": "Validation failed.", "details": errors}), 400

    db = get_db()
    try:
        cur = db.execute(
            "INSERT INTO students (name, email, course, marks) VALUES (?, ?, ?, ?)",
            (data["name"].strip(), data["email"].strip(), data["course"].strip(), float(data["marks"])),
        )
        db.commit()
        new_row = db.execute("SELECT * FROM students WHERE id = ?", (cur.lastrowid,)).fetchone()
        return jsonify(row_to_dict(new_row)), 201
    except sqlite3.IntegrityError:
        return jsonify({"error": "A student with this email already exists."}), 409
    except sqlite3.Error as e:
        return jsonify({"error": "Database error.", "details": str(e)}), 500


# READ ALL (supports optional ?search= query for name/course filtering)
@app.route("/api/students", methods=["GET"])
def get_students():
    db = get_db()
    search = request.args.get("search", "").strip()
    try:
        if search:
            like = f"%{search}%"
            rows = db.execute(
                "SELECT * FROM students WHERE name LIKE ? OR course LIKE ? ORDER BY id",
                (like, like),
            ).fetchall()
        else:
            rows = db.execute("SELECT * FROM students ORDER BY id").fetchall()
        return jsonify([row_to_dict(r) for r in rows]), 200
    except sqlite3.Error as e:
        return jsonify({"error": "Database error.", "details": str(e)}), 500


# READ ONE
@app.route("/api/students/<int:student_id>", methods=["GET"])
def get_student(student_id):
    db = get_db()
    row = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    if row is None:
        return jsonify({"error": f"Student with id {student_id} not found."}), 404
    return jsonify(row_to_dict(row)), 200


# UPDATE
@app.route("/api/students/<int:student_id>", methods=["PUT", "PATCH"])
def update_student(student_id):
    db = get_db()
    existing = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    if existing is None:
        return jsonify({"error": f"Student with id {student_id} not found."}), 404

    data = request.get_json(silent=True)
    if data is None:
        return jsonify({"error": "Request body must be valid JSON."}), 400

    partial = request.method == "PATCH"
    errors = validate_student_payload(data, partial=partial)
    if errors:
        return jsonify({"error": "Validation failed.", "details": errors}), 400

    merged = {
        "name": data.get("name", existing["name"]).strip() if "name" in data else existing["name"],
        "email": data.get("email", existing["email"]).strip() if "email" in data else existing["email"],
        "course": data.get("course", existing["course"]).strip() if "course" in data else existing["course"],
        "marks": float(data.get("marks", existing["marks"])) if "marks" in data else existing["marks"],
    }

    try:
        db.execute(
            "UPDATE students SET name = ?, email = ?, course = ?, marks = ? WHERE id = ?",
            (merged["name"], merged["email"], merged["course"], merged["marks"], student_id),
        )
        db.commit()
        row = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
        return jsonify(row_to_dict(row)), 200
    except sqlite3.IntegrityError:
        return jsonify({"error": "A student with this email already exists."}), 409
    except sqlite3.Error as e:
        return jsonify({"error": "Database error.", "details": str(e)}), 500


# DELETE
@app.route("/api/students/<int:student_id>", methods=["DELETE"])
def delete_student(student_id):
    db = get_db()
    existing = db.execute("SELECT * FROM students WHERE id = ?", (student_id,)).fetchone()
    if existing is None:
        return jsonify({"error": f"Student with id {student_id} not found."}), 404

    try:
        db.execute("DELETE FROM students WHERE id = ?", (student_id,))
        db.commit()
        return jsonify({"message": f"Student with id {student_id} deleted successfully."}), 200
    except sqlite3.Error as e:
        return jsonify({"error": "Database error.", "details": str(e)}), 500


# --------------------------------------------------------------------------
# Global error handlers (SOP section 11 - Security and Quality)
# --------------------------------------------------------------------------
@app.errorhandler(404)
def not_found(e):
    return jsonify({"error": "Resource not found."}), 404


@app.errorhandler(405)
def method_not_allowed(e):
    return jsonify({"error": "Method not allowed."}), 405


@app.errorhandler(500)
def server_error(e):
    return jsonify({"error": "Internal server error."}), 500


if __name__ == "__main__":
    init_db()
    app.run(debug=True, port=5000)
